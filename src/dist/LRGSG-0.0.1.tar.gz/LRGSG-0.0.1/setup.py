from setuptools import setup

setup(
   name='LRGSG',
   version='0.0.1',
   description='A useful module',
   author='Giulio Iannelli',
   author_email='giulioiannelli.w@gmail.com',
   packages=['LRGSG_package'],  #same as name
   install_requires=['numpy'], #external packages as dependencies
)
